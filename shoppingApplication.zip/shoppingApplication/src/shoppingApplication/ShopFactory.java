package shoppingApplication;

public abstract class ShopFactory {
	public abstract PrimeAcc getNewPrimeAcc(int accNo,String accNm,float charges,boolean isPrime);
	public abstract NormalAcc getNewNormalAcc(int accNo,String accNum,float charges,float deliveryCharges);

}
