package shoppingApplication;

public abstract class NormalAcc extends ShopAcc {
	private float deliveryCharges;
	public NormalAcc(int accNo, String accNm, float charges,float deliveryCharges) {
		super(accNo, accNm, charges);
		// TODO Auto-generated constructor stub
		this.setDeliveryCharges(deliveryCharges);
	}
	@Override
	public void bookProduct(float amount) {
		setCharges(getCharges()+amount+getDeliveryCharges());
	}
	@Override
	public String toString() {
		return "Account No: " + getAccNo() + "\nAccount Name: " + getAccNm() + "\nCharges: " + getCharges()+"\nDelivery Charges: "+getDeliveryCharges();
		
	}
	public float getDeliveryCharges() {
		return deliveryCharges;
	}
	public void setDeliveryCharges(float deliveryCharges) {
		this.deliveryCharges = deliveryCharges;
	}

	

}
