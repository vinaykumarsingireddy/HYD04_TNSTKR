package shoppingApplication;

public abstract class PrimeAcc extends ShopAcc {
	private boolean isPrime;
	private float deliveryCharges;

	public PrimeAcc(int accNo, String accNm, float charges,boolean isPrime) {
		super(accNo, accNm, charges);
		// TODO Auto-generated constructor stub
		this.setPrime(isPrime);
	}
	public void bookProduct(float amount) {
		if(!isPrime()) {
			setCharges(getCharges()+amount);
		}
	}
	@Override
	public String toString() {
		return "Account No: " + getAccNo() + "\nAccount Name: " + getAccNm() + "\nCharges: " + getCharges()+ "\nPrime account: "+isPrime();
	}
	public boolean isPrime() {
		return isPrime;
	}
	public void setPrime(boolean isPrime) {
		this.isPrime = isPrime;
	}

}
