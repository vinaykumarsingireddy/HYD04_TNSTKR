package shoppingApplication;

public abstract class ShopAcc {
	private int accNo;
    private String accNm;
    private float charges;
    public ShopAcc(int accNo, String accNm, float charges) {
        this.setAccNo(accNo);
        this.setAccNm(accNm);
        this.setCharges(charges);
    }
    public abstract void bookProduct(float amount);
    public abstract void items(float quantity);
    @Override
    public String toString() {
    	 return "Account No: " + getAccNo() + "\nAccount Name: " + getAccNm() + "\nCharges: " + getCharges();
    	
    }
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	public String getAccNm() {
		return accNm;
	}
	public void setAccNm(String accNm) {
		this.accNm = accNm;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

}
