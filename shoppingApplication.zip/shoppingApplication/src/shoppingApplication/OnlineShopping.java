package shoppingApplication;

public class OnlineShopping {
	public static void main(String[] args) {
        ShopFactory shopFactory = new GSShopFactory();
        
        PrimeAcc primeAcc = shopFactory.getNewPrimeAcc(1, "PrimeUser", 100, true);
        NormalAcc normalAcc = shopFactory.getNewNormalAcc(2, "NormalUser", 150, 10);
        
        primeAcc.bookProduct(50);
        normalAcc.bookProduct(50);
        
        System.out.println("Prime Account Info:\n" + primeAcc);
        System.out.println("\nNormal Account Info:\n" + normalAcc);
    }

}
