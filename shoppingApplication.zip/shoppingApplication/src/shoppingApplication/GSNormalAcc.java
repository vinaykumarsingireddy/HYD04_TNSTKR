package shoppingApplication;

public class GSNormalAcc extends NormalAcc {
	    public GSNormalAcc(int accNo, String accNm, float charges, float deliveryCharges) {
	        super(accNo, accNm, charges, deliveryCharges);
	    }

		@Override
		public void items(float quantity) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void bookProduct(float amount) {
			setCharges(getCharges()+amount+getDeliveryCharges());
		}
		@Override
		public String toString() {
			return "Account No: " + getAccNo() + "\nAccount Name: " + getAccNm() + "\nCharges: " + getCharges()+"\nDelivery Charges: "+getDeliveryCharges();
			
		}
	}



