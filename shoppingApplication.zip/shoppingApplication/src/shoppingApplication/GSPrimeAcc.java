package shoppingApplication;

public class GSPrimeAcc extends PrimeAcc{
	private float Charges;
	public GSPrimeAcc(int accNo, String accNm, float charges, boolean isPrime) {
		super(accNo, accNm, charges, isPrime);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void bookProduct(float amount) {
		if(!isPrime()) {
			setCharges(getCharges()+amount);
		}
	}
	@Override
	public String toString() {
		return "Account No: " + getAccNo() + "\nAccount Name: " + getAccNm() + "\nCharges: " + getCharges()+ "\nPrime account: "+isPrime();
		
	}
	@Override
	public void items(float quantity) {
		// TODO Auto-generated method stub
		
		
	}

}
